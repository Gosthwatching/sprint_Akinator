<?php
$pdo = getConnexion();