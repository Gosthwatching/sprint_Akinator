<?php


$template = "index";
include "layout.phtml";